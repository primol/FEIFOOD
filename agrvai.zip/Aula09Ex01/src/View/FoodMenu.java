/*
 * Main Food Menu Window
 */
package View;

import Controller.FoodMenuController;
import Model.Food;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 *
 * @author unifvipereira
 */
public class FoodMenu extends javax.swing.JFrame {

    private FoodMenuController controller;
    private DefaultListModel<Food> foodListModel;
    
    /**
     * Creates new form FoodMenu
     */
    public FoodMenu() {
        initComponents();
        foodListModel = new DefaultListModel<>();
        foodList.setModel(foodListModel);
        controller = new FoodMenuController(this);
        controller.loadFoods();
    }

    public JList<Food> getFoodList() {
        return foodList;
    }

    public DefaultListModel<Food> getFoodListModel() {
        return foodListModel;
    }

    public JTextField getTxtSearch() {
        return txtSearch;
    }

    public javax.swing.JButton getBtnAddToCart() {
        return btnAddToCart;
    }

    public javax.swing.JButton getBtnViewDetails() {
        return btnViewDetails;
    }

    public javax.swing.JButton getBtnViewCart() {
        return btnViewCart;
    }

    public javax.swing.JButton getBtnSearch() {
        return btnSearch;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        foodList = new javax.swing.JList<>();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnAddToCart = new javax.swing.JButton();
        btnViewDetails = new javax.swing.JButton();
        btnViewCart = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        lblCartCount = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("iFood - Menu");
        setResizable(false);
        getContentPane().setBackground(new java.awt.Color(245, 245, 245));

        foodList.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        foodList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        foodList.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(foodList);
        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setToolTipText("Digite o nome, descrição ou categoria do alimento");
        txtSearch.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(200, 200, 200)),
            javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        btnSearch.setBackground(new java.awt.Color(255, 87, 34));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("🔍 Buscar");
        btnSearch.setBorderPainted(false);
        btnSearch.setFocusPainted(false);
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        btnAddToCart.setBackground(new java.awt.Color(255, 87, 34));
        btnAddToCart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAddToCart.setForeground(new java.awt.Color(255, 255, 255));
        btnAddToCart.setText("➕ Adicionar");
        btnAddToCart.setBorderPainted(false);
        btnAddToCart.setFocusPainted(false);
        btnAddToCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddToCartActionPerformed(evt);
            }
        });

        btnViewDetails.setBackground(new java.awt.Color(255, 87, 34));
        btnViewDetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnViewDetails.setForeground(new java.awt.Color(255, 255, 255));
        btnViewDetails.setText("ℹ️ Detalhes");
        btnViewDetails.setBorderPainted(false);
        btnViewDetails.setFocusPainted(false);
        btnViewDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewDetailsActionPerformed(evt);
            }
        });

        btnViewCart.setBackground(new java.awt.Color(255, 87, 34));
        btnViewCart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnViewCart.setForeground(new java.awt.Color(255, 255, 255));
        btnViewCart.setText("🛒 Carrinho");
        btnViewCart.setBorderPainted(false);
        btnViewCart.setFocusPainted(false);
        btnViewCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewCartActionPerformed(evt);
            }
        });

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 87, 34));
        lblTitle.setText("🍔 iFood");

        lblCartCount.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCartCount.setForeground(new java.awt.Color(255, 87, 34));
        lblCartCount.setText("🛒 0 itens");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAddToCart, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnViewDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnViewCart, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblCartCount)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTitle)
                    .addComponent(lblCartCount))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddToCart, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewCart, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        controller.searchFoods();
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToCartActionPerformed
        controller.addToCart();
    }//GEN-LAST:event_btnAddToCartActionPerformed

    private void btnViewDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewDetailsActionPerformed
        controller.viewDetails();
    }//GEN-LAST:event_btnViewDetailsActionPerformed

    private void btnViewCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewCartActionPerformed
        controller.viewCart();
    }//GEN-LAST:event_btnViewCartActionPerformed

    public void updateCartCount(int count) {
        lblCartCount.setText("Carrinho: " + count + " itens");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddToCart;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnViewCart;
    private javax.swing.JButton btnViewDetails;
    private javax.swing.JList<Food> foodList;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCartCount;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}

